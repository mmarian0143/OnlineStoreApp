-- Run SELECT statement to grab the Quantity from Cart.

SELECT Quantity FROM Cart
-- Run SELECT ALL statement to grab contents from Products. 

SELECT * FROM Products
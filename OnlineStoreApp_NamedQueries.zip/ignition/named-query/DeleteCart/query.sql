-- Run DELETE statement to delete contents from Cart after a purchase has occurred. 

DELETE FROM Cart
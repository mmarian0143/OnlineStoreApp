-- Run SELECT statement to grab contents from the Orders table. 
-- Rename the columns to a more appropriate name that will better be displayed on the Ignition Views.
SELECT 
Date AS 'Date Purchased', 
OrderID AS 'Confirmation ID', 
Name AS 'Product Name', 
Description AS 'Product Description', 
Total AS 'Total Amount'
FROM Orders
-- The following WHERE condition will allow the user to select between 
-- two Calendar dates on the Ignition View.
WHERE Date BETWEEN :startDate AND :endDate
-- Run SELECT statement to grab contents from Cart. 
-- Rename the columns to a more appropriate name that will better be displayed on the Ignition Views.

SELECT
Name AS 'Product Name', 
Description AS 'Product Description', 
Price
FROM Cart
-- Run SELECT ALL statement to grab contents from Users. 

SELECT * FROM Users